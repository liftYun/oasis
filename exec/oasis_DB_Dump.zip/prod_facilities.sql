-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: stay-oasis.kr    Database: prod
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `facilities`
--

DROP TABLE IF EXISTS `facilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facilities` (
  `facilities_id` bigint NOT NULL AUTO_INCREMENT,
  `category` enum('AMENITY','BATHROOM','BEDROOM','KITCHEN','SERVICE') NOT NULL,
  `facilities_name` varchar(255) NOT NULL,
  `facilities_name_eng` varchar(255) NOT NULL,
  PRIMARY KEY (`facilities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facilities`
--

LOCK TABLES `facilities` WRITE;
/*!40000 ALTER TABLE `facilities` DISABLE KEYS */;
INSERT INTO `facilities` VALUES (1,'BATHROOM','욕조','Bathtub'),(2,'BATHROOM','샤워 부스','Shower booth'),(3,'BATHROOM','드라이기','Hair dryer'),(4,'BATHROOM','샴푸 / 린스 / 바디워시','Shampoo / Rinse / Body wash'),(5,'BATHROOM','수건 제공','Towels provided'),(6,'BATHROOM','치약 / 칫솔','Toothpaste / Toothbrush'),(7,'BATHROOM','면도기','Razor'),(8,'BATHROOM','온수','Hot water'),(9,'BEDROOM','싱글베드','Single bed'),(10,'BEDROOM','더블베드','Double bed'),(11,'BEDROOM','트윈베드','Twin bed'),(12,'BEDROOM','퀸 / 킹사이즈 베드','Queen / King size bed'),(13,'BEDROOM','쇼파베드','Sofa bed'),(14,'BEDROOM','추가 침대 가능 여부','Extra bed availability'),(15,'BEDROOM','암막 커튼','Blackout curtain'),(16,'KITCHEN','냉장고','Refrigerator'),(17,'KITCHEN','전자레인지','Microwave'),(18,'KITCHEN','커피머신','Coffee machine'),(19,'KITCHEN','인덕션 / 가스레인지','Stove / Gas range'),(20,'KITCHEN','조리도구 / 식기','Cookware / Tableware'),(21,'KITCHEN','전기포트','Electric kettle'),(22,'KITCHEN','무료 생수','Free bottled water'),(23,'AMENITY','무료 Wi-Fi','Free Wi-Fi'),(24,'AMENITY','케이블 TV','Cable TV'),(25,'AMENITY','OTT 지원','OTT Service'),(26,'AMENITY','에어컨','Air conditioner'),(27,'AMENITY','난방','Heating'),(28,'AMENITY','우풍 / 환기','Ventilation'),(29,'AMENITY','스타일러','Clothing Styler'),(30,'AMENITY','세탁기','Washing machine'),(31,'AMENITY','건조기','Dryer'),(32,'AMENITY','책상 / 업무 공간','Desk / Workspace'),(33,'SERVICE','편의점 / 마트 5분 이내','Convenience store / Mart within 5 min'),(34,'SERVICE','대중교통 근처','Close to public transportation'),(35,'SERVICE','무료 / 유료 주차장','Free / Paid parking'),(36,'SERVICE','카페 / 식당 밀집 지역','Cafe / Restaurant area'),(37,'SERVICE','주요 관광지 / 쇼핑몰 인접','Near tourist attractions / Shopping mall'),(38,'SERVICE','공원 / 산책로 접근성','Park / Walking trail accessibility');
/*!40000 ALTER TABLE `facilities` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29  9:16:46
