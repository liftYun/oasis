-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: stay-oasis.kr    Database: prod
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservations` (
  `reservation_id` varchar(191) NOT NULL,
  `challenge_id` varchar(191) DEFAULT NULL,
  `checkin_date` datetime(6) NOT NULL,
  `checkout_date` datetime(6) NOT NULL,
  `is_canceled` bit(1) NOT NULL,
  `is_reviewed` bit(1) NOT NULL,
  `is_settlemented` bit(1) NOT NULL,
  `payment` int NOT NULL,
  `reservation_date` datetime(6) NOT NULL,
  `status` enum('APPROVED','CANCELED','LOCKED','PENDING','PENDING_APPROVED','PENDING_LOCK','SETTLEMENTED','SETTLEMENT_FAILED') NOT NULL,
  `stay_title` varchar(255) NOT NULL,
  `stay_title_eng` varchar(255) NOT NULL,
  `stay_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`reservation_id`),
  KEY `FKl66m1f8fgxaor7mu16xq8ggat` (`stay_id`),
  KEY `FKb5g9io5h54iwl2inkno50ppln` (`user_id`),
  CONSTRAINT `FKb5g9io5h54iwl2inkno50ppln` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `FKl66m1f8fgxaor7mu16xq8ggat` FOREIGN KEY (`stay_id`) REFERENCES `stays` (`stay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES ('0x2c3053c4e2db37c959cfbed12844ce30476ea82cfa5b32cbd8291e518955cac2','1e691bfc-6f4c-52b2-ac3a-999bf5e43c2d','2025-09-28 09:00:00.000000','2025-09-29 11:00:00.000000',_binary '\0',_binary '\0',_binary '\0',1,'2025-09-29 03:37:00.577843','LOCKED','미니홈','미니홈',36,5),('0x2f1d8deb0086f17df0c62f6a9485f8ab25b378353105590e6ac18b85158e76bc','a502e644-ab44-58ca-9b6f-4ed0bf5c6e76','2025-10-05 20:59:35.000000','2025-10-06 20:59:35.000000',_binary '\0',_binary '\0',_binary '\0',10,'2025-09-28 20:59:36.217100','LOCKED','광안 바이브','Gwang-an Vibe',35,11),('0x42317a3f979b64e62da9abbd3f09b1a02cd166abaecbd664f40bcb73562f6429','a717d42a-a386-584d-b232-a98f87da712e','2025-10-05 09:00:00.000000','2025-10-06 11:00:00.000000',_binary '\0',_binary '\0',_binary '\0',10,'2025-09-28 23:44:29.856215','LOCKED','광안 바이브','Gwang-an Vibe',35,12),('0x51ca8df0826559db4dcc65f9b0f4d1ec6dd2f15e5a1942890d70876bdbef3f85','2aceba21-1c7f-5ba2-b913-6bbfabae96ee','2025-09-05 09:00:00.000000','2025-09-05 11:00:00.000000',_binary '\0',_binary '',_binary '',10,'2025-09-28 23:18:05.686976','SETTLEMENTED','광안 바이브','Gwang-an Vibe',35,12),('0x62c62327f10578652b220ada63c46f390416f22103bfee21d8076f6876d06cc5','76de1d73-b2f7-5335-aa11-72a087710ba4','2025-09-28 09:00:00.000000','2025-09-29 11:00:00.000000',_binary '\0',_binary '\0',_binary '\0',1,'2025-09-29 01:36:38.952941','LOCKED','미니홈','미니홈',36,12),('0xa29bb86454973df52f644cee85ae2d2b9f8585d77ef48ce54656a8c5287ab8c4','1310d1ae-dee2-554d-b9be-aa3bf0fece15','2025-10-05 09:00:00.000000','2025-10-06 11:00:00.000000',_binary '\0',_binary '\0',_binary '\0',10,'2025-09-28 23:44:56.744696','LOCKED','광안 바이브','Gwang-an Vibe',35,12),('0xab901aa1d790b4d1a7b49ed426b75e3329c096a0354dfa00bf13d705511a6281','7ca27d01-b774-55df-a59d-10461e520f9c','2025-10-05 09:00:00.000000','2025-10-06 11:00:00.000000',_binary '\0',_binary '',_binary '',10,'2025-09-28 23:37:56.995548','LOCKED','광안 바이브','Gwang-an Vibe',35,12),('0xb72b552092f24c3095a4aa02bf2314173405a218b05934d8bd415e927e50ba85','b209ec67-bf52-534f-847f-69b541d126f2','2025-09-28 09:00:00.000000','2025-09-29 11:00:00.000000',_binary '\0',_binary '\0',_binary '\0',1,'2025-09-29 01:40:43.093989','LOCKED','미니홈','미니홈',36,11),('0xc61ddd9dce8f58f97581b2ca984e48d2dc1565e81a46b1dc03899507736d2976','8a84b5b2-592e-5b5f-861a-2605a1ab47f7','2025-10-06 09:00:00.000000','2025-10-07 11:00:00.000000',_binary '\0',_binary '\0',_binary '\0',1,'2025-09-29 00:52:14.659078','LOCKED','미니홈','미니홈',36,11),('0xde32296291b8822d4b1ad9c1dfec53fcc3eb8b2855ae0722017f906834918e8a','d8f3c717-0d3e-5d6d-8da5-a1d14eb8c3a5','2025-10-05 18:39:32.000000','2025-10-06 18:39:32.000000',_binary '\0',_binary '\0',_binary '\0',90,'2025-09-28 18:39:32.045892','APPROVED','그린코티지 연산','Green Cottage Yeonsan',34,10),('0xff94abe4bae111ac91bd0790d8ecb4b58b8f6913c231f4219d34600398009744','0776e4fa-79a2-510b-a0e9-a577c44196a7','2025-10-05 18:39:19.000000','2025-10-06 18:39:19.000000',_binary '\0',_binary '\0',_binary '\0',90,'2025-09-28 18:39:18.814103','PENDING','그린코티지 연산','Green Cottage Yeonsan',34,10);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29  9:16:52
