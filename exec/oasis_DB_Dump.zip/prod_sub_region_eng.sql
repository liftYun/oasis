-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: stay-oasis.kr    Database: prod
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sub_region_eng`
--

DROP TABLE IF EXISTS `sub_region_eng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_region_eng` (
  `sub_region_id` bigint NOT NULL AUTO_INCREMENT,
  `sub_name` varchar(255) NOT NULL,
  `upper_name` varchar(255) NOT NULL,
  PRIMARY KEY (`sub_region_id`),
  KEY `FKmr18jnjuy7pxfj3bx9wbfffdp` (`upper_name`),
  CONSTRAINT `FKmr18jnjuy7pxfj3bx9wbfffdp` FOREIGN KEY (`upper_name`) REFERENCES `region_eng` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_region_eng`
--

LOCK TABLES `sub_region_eng` WRITE;
/*!40000 ALTER TABLE `sub_region_eng` DISABLE KEYS */;
INSERT INTO `sub_region_eng` VALUES (1,'Gangnam-gu','Seoul'),(2,'Gangdong-gu','Seoul'),(3,'Gangbuk-gu','Seoul'),(4,'Gangseo-gu','Seoul'),(5,'Gwanak-gu','Seoul'),(6,'Gwangjin-gu','Seoul'),(7,'Guro-gu','Seoul'),(8,'Geumcheon-gu','Seoul'),(9,'Nowon-gu','Seoul'),(10,'Dobong-gu','Seoul'),(11,'Dongdaemun-gu','Seoul'),(12,'Dongjak-gu','Seoul'),(13,'Mapo-gu','Seoul'),(14,'Seodaemun-gu','Seoul'),(15,'Seocho-gu','Seoul'),(16,'Seongdong-gu','Seoul'),(17,'Seongbuk-gu','Seoul'),(18,'Songpa-gu','Seoul'),(19,'Yangcheon-gu','Seoul'),(20,'Yeongdeungpo-gu','Seoul'),(21,'Yongsan-gu','Seoul'),(22,'Eunpyeong-gu','Seoul'),(23,'Jongno-gu','Seoul'),(24,'Jung-gu','Seoul'),(25,'Jungnang-gu','Seoul'),(26,'Gangseo-gu','Busan'),(27,'Geumjeong-gu','Busan'),(28,'Nam-gu','Busan'),(29,'Dong-gu','Busan'),(30,'Dongnae-gu','Busan'),(31,'Busanjin-gu','Busan'),(32,'Buk-gu','Busan'),(33,'Sasang-gu','Busan'),(34,'Saha-gu','Busan'),(35,'Seo-gu','Busan'),(36,'Suyeong-gu','Busan'),(37,'Yeonje-gu','Busan'),(38,'Yeongdo-gu','Busan'),(39,'Jung-gu','Busan'),(40,'Haeundae-gu','Busan'),(41,'Nam-gu','Daegu'),(42,'Dalseo-gu','Daegu'),(43,'Dong-gu','Daegu'),(44,'Buk-gu','Daegu'),(45,'Seo-gu','Daegu'),(46,'Suseong-gu','Daegu'),(47,'Jung-gu','Daegu'),(48,'Gyeyang-gu','Incheon'),(49,'Namdong-gu','Incheon'),(50,'Dong-gu','Incheon'),(51,'Michuhol-gu','Incheon'),(52,'Bupyeong-gu','Incheon'),(53,'Seo-gu','Incheon'),(54,'Yeonsu-gu','Incheon'),(55,'Jung-gu','Incheon'),(56,'Dong-gu','Gwangju'),(57,'Seo-gu','Gwangju'),(58,'Nam-gu','Gwangju'),(59,'Buk-gu','Gwangju'),(60,'Gwangsan-gu','Gwangju'),(61,'Dong-gu','Daejeon'),(62,'Seo-gu','Daejeon'),(63,'Jung-gu','Daejeon'),(64,'Yuseong-gu','Daejeon'),(65,'Daedeok-gu','Daejeon'),(66,'Jung-gu','Ulsan'),(67,'Nam-gu','Ulsan'),(68,'Dong-gu','Ulsan'),(69,'Buk-gu','Ulsan'),(70,'Suwon-si','Gyeonggi'),(71,'Seongnam-si','Gyeonggi'),(72,'Goyang-si','Gyeonggi'),(73,'Yongin-si','Gyeonggi'),(74,'Bucheon-si','Gyeonggi'),(75,'Ansan-si','Gyeonggi'),(76,'Anyang-si','Gyeonggi'),(77,'Namyangju-si','Gyeonggi'),(78,'Hwaseong-si','Gyeonggi'),(79,'Pyeongtaek-si','Gyeonggi'),(80,'Uijeongbu-si','Gyeonggi'),(81,'Siheung-si','Gyeonggi'),(82,'Gimpo-si','Gyeonggi'),(83,'Gwangmyeong-si','Gyeonggi'),(84,'Gwangju-si','Gyeonggi'),(85,'Gunpo-si','Gyeonggi'),(86,'Icheon-si','Gyeonggi'),(87,'Yangju-si','Gyeonggi'),(88,'Osan-si','Gyeonggi'),(89,'Guri-si','Gyeonggi'),(90,'Anseong-si','Gyeonggi'),(91,'Pocheon-si','Gyeonggi'),(92,'Uiwang-si','Gyeonggi'),(93,'Hanam-si','Gyeonggi'),(94,'Yeoju-si','Gyeonggi'),(95,'Dongducheon-si','Gyeonggi'),(96,'Gwacheon-si','Gyeonggi'),(97,'Paju-si','Gyeonggi'),(98,'Chuncheon-si','Gangwon'),(99,'Wonju-si','Gangwon'),(100,'Gangneung-si','Gangwon'),(101,'Donghae-si','Gangwon'),(102,'Taebaek-si','Gangwon'),(103,'Sokcho-si','Gangwon'),(104,'Samcheok-si','Gangwon'),(105,'Cheongju-si','Chungcheongbuk'),(106,'Chungju-si','Chungcheongbuk'),(107,'Jecheon-si','Chungcheongbuk'),(108,'Cheonan-si','Chungcheongnam'),(109,'Gongju-si','Chungcheongnam'),(110,'Boryeong-si','Chungcheongnam'),(111,'Asan-si','Chungcheongnam'),(112,'Seosan-si','Chungcheongnam'),(113,'Nonsan-si','Chungcheongnam'),(114,'Gyeryong-si','Chungcheongnam'),(115,'Dangjin-si','Chungcheongnam'),(116,'Sejong-si','Chungcheongnam'),(117,'Jeonju-si','Jeollabuk'),(118,'Gunsan-si','Jeollabuk'),(119,'Iksan-si','Jeollabuk'),(120,'Jeongeup-si','Jeollabuk'),(121,'Namwon-si','Jeollabuk'),(122,'Gimje-si','Jeollabuk'),(123,'Mokpo-si','Jeollanam'),(124,'Yeosu-si','Jeollanam'),(125,'Suncheon-si','Jeollanam'),(126,'Naju-si','Jeollanam'),(127,'Gwangyang-si','Jeollanam'),(128,'Pohang-si','Gyeongsangbuk'),(129,'Gyeongju-si','Gyeongsangbuk'),(130,'Gimcheon-si','Gyeongsangbuk'),(131,'Andong-si','Gyeongsangbuk'),(132,'Gumi-si','Gyeongsangbuk'),(133,'Yeongju-si','Gyeongsangbuk'),(134,'Yeongcheon-si','Gyeongsangbuk'),(135,'Sangju-si','Gyeongsangbuk'),(136,'Mungyeong-si','Gyeongsangbuk'),(137,'Gyeongsan-si','Gyeongsangbuk'),(138,'Changwon-si','Gyeongsangnam'),(139,'Jinju-si','Gyeongsangnam'),(140,'Tongyeong-si','Gyeongsangnam'),(141,'Sacheon-si','Gyeongsangnam'),(142,'Gimhae-si','Gyeongsangnam'),(143,'Miryang-si','Gyeongsangnam'),(144,'Geoje-si','Gyeongsangnam'),(145,'Yangsan-si','Gyeongsangnam'),(146,'Jeju-si','Jeju'),(147,'Seogwipo-si','Jeju');
/*!40000 ALTER TABLE `sub_region_eng` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29  9:16:56
