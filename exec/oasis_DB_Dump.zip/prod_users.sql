-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: stay-oasis.kr    Database: prod
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `certificate_key` varchar(191) DEFAULT NULL,
  `certificate_url` varchar(191) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `first_login` bit(1) NOT NULL,
  `language` enum('ENG','KOR') NOT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `profile_url` varchar(191) DEFAULT NULL,
  `role` enum('ROLE_GUEST','ROLE_HOST') NOT NULL,
  `user_uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uk_users_email` (`email`),
  UNIQUE KEY `UK4mcg6l0va97nbd8o9tqpeg104` (`user_uuid`),
  UNIQUE KEY `uk_users_nickname` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (5,'2025-09-28 00:45:39.466150','2025-09-29 03:31:13.112187',NULL,NULL,'minhe8564@gmail.com',_binary '\0','KOR','미니호스트','https://lh3.googleusercontent.com/a/ACg8ocIjXcK5PFRuLNZlLLnwMDsWTVvm_KpXdM-NEhEhXvecNeq7=s96-c','ROLE_HOST','588a4b3b-69fb-4e1a-8866-1573fc594068'),(6,'2025-09-28 00:46:42.550722','2025-09-28 00:46:56.432767',NULL,NULL,'d.vaming2@gmail.com',_binary '\0','KOR','정지용','https://lh3.googleusercontent.com/a/ACg8ocJ_PwqJamt4r1ZEHDKTn61nLTZUB18MkTb57sIfGKLeKfGlmg4=s96-c','ROLE_GUEST','c2b36fdf-3acc-4062-9e3d-38e25d0f77e1'),(7,'2025-09-28 09:30:31.791681','2025-09-28 09:30:49.191106',NULL,NULL,'1811242@donga.ac.kr',_binary '\0','KOR','호스트윤','https://lh3.googleusercontent.com/a/ACg8ocKWgY8CihuxEpQo5r-i-8az9Pgliz_zwewOd4XAK4P9fImQug=s96-c','ROLE_HOST','14ab81f6-11de-424b-a564-24af32fe2043'),(8,'2025-09-28 13:13:04.327703','2025-09-28 13:13:04.327703',NULL,NULL,'singingtheflute@gmail.com',_binary '','KOR','Doyun Lee (lift_yun)','https://lh3.googleusercontent.com/a/ACg8ocJGNW1Wqq28ye-Xx8xrrR_GuHOn9lKzVHK-kyZOhldg99l-muLK=s96-c','ROLE_GUEST','e36cc525-a659-4b88-81da-d00d867b883f'),(9,'2025-09-28 18:11:54.971987','2025-09-28 18:13:50.517619',NULL,NULL,'yoonsu0325@gmail.com',_binary '\0','KOR','호스트박','https://stay-oasis.s3.ap-northeast-2.amazonaws.com/users/cdcde150-4db1-4ff5-9da6-6e45d98606ad/profile/98384822-7ca8-4f6c-b252-7430d8d23d69.jpg','ROLE_HOST','cdcde150-4db1-4ff5-9da6-6e45d98606ad'),(10,'2025-09-28 18:37:04.657497','2025-09-28 18:37:37.756191',NULL,NULL,'nexon.maple.god@gmail.com',_binary '\0','KOR','신창섭아님','https://lh3.googleusercontent.com/a/ACg8ocKLfMnTSQ3LTC5UXBAorU-ki2qXRnoWxJL_zmz9nwmwvIaNQ9s=s96-c','ROLE_GUEST','fc295e21-7931-45a0-bc41-0e97d5c59859'),(11,'2025-09-28 20:41:55.101224','2025-09-28 20:45:50.437733',NULL,NULL,'yunseow0914@gmail.com',_binary '\0','ENG','Gerry','https://stay-oasis.s3.ap-northeast-2.amazonaws.com/users/a546dbfe-4054-428f-a13b-63d55bb47c12/profile/bc1f890c-8804-40e0-ac76-e4d628919b49.jpg','ROLE_GUEST','a546dbfe-4054-428f-a13b-63d55bb47c12'),(12,'2025-09-28 22:39:24.152340','2025-09-28 22:39:55.309238',NULL,NULL,'liftyun@gmail.com',_binary '\0','KOR','게스튠','https://lh3.googleusercontent.com/a/ACg8ocJeZT8vt4D2MDyFe3zv3eLOwf223vi8_p8U0Nx9xroA07EGQg=s96-c','ROLE_GUEST','26f6990b-2564-4d34-b729-aeaa1690d346'),(13,'2025-09-29 00:34:07.739029','2025-09-29 00:34:07.739029',NULL,NULL,'jieun9452@gmail.com',_binary '','KOR','이지은','https://lh3.googleusercontent.com/a/ACg8ocKDKU-mHk7tL7EvdNp3uxWEnT7ZyUtrQM5ef-Sbx8YsOMQJUQ=s96-c','ROLE_GUEST','21f24a8c-c9dd-4557-b818-a806bebd5f1a'),(14,'2025-09-29 02:42:27.457358','2025-09-29 02:42:42.113923',NULL,NULL,'ssafy1303@gmail.com',_binary '\0','KOR','박정훈','https://lh3.googleusercontent.com/a/ACg8ocIoMYnYbh0floUZ-T7WhOMXO3Gxs19x-zaQ69esS-Jj2tDPMQ=s96-c','ROLE_GUEST','184662fb-e2d1-455f-95f0-2baeb1c9a327');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29  9:16:54
