-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: stay-oasis.kr    Database: prod
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `key_owner`
--

DROP TABLE IF EXISTS `key_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `key_owner` (
  `key_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `reservation_id` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`key_id`,`user_id`),
  KEY `FKitxpiammmeh6sucma1xx41mws` (`user_id`),
  KEY `FKgo7os32y19rmud2q6hv1qroon` (`reservation_id`),
  CONSTRAINT `FKgo7os32y19rmud2q6hv1qroon` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`reservation_id`),
  CONSTRAINT `FKitxpiammmeh6sucma1xx41mws` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `FKstlegkkv6ggilbrgdgieu92yg` FOREIGN KEY (`key_id`) REFERENCES `digital_key` (`key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `key_owner`
--

LOCK TABLES `key_owner` WRITE;
/*!40000 ALTER TABLE `key_owner` DISABLE KEYS */;
INSERT INTO `key_owner` VALUES (19,5,'0x2c3053c4e2db37c959cfbed12844ce30476ea82cfa5b32cbd8291e518955cac2'),(8,9,'0x2f1d8deb0086f17df0c62f6a9485f8ab25b378353105590e6ac18b85158e76bc'),(8,11,'0x2f1d8deb0086f17df0c62f6a9485f8ab25b378353105590e6ac18b85158e76bc'),(17,12,'0x62c62327f10578652b220ada63c46f390416f22103bfee21d8076f6876d06cc5'),(18,9,'0xb72b552092f24c3095a4aa02bf2314173405a218b05934d8bd415e927e50ba85'),(18,11,'0xb72b552092f24c3095a4aa02bf2314173405a218b05934d8bd415e927e50ba85'),(14,11,'0xc61ddd9dce8f58f97581b2ca984e48d2dc1565e81a46b1dc03899507736d2976');
/*!40000 ALTER TABLE `key_owner` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29  9:16:50
